@file:OptIn(ExperimentalLayoutApi::class)

package com.school.attendance.ui

import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.school.attendance.data.AttendanceRecord
import com.school.attendance.data.Student
import com.school.attendance.logic.*
import java.time.LocalDate

private fun colWidth(header: String): Dp = when (header) {
    "Name" -> 150.dp
    "Date" -> 110.dp
    "Attendance %", "Status" -> 100.dp
    else -> 72.dp
}

@Composable
private fun ReportTable(report: Report) {
    val shown = report.rows.take(100)
    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface), modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.horizontalScroll(rememberScrollState()).padding(8.dp)) {
            Row {
                report.headers.forEach { h ->
                    Text(h, modifier = Modifier.width(colWidth(h)).padding(4.dp), fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelLarge)
                }
            }
            HorizontalDivider()
            shown.forEach { row ->
                Row {
                    row.forEachIndexed { i, cell ->
                        Text(
                            cell,
                            modifier = Modifier.width(colWidth(report.headers[i])).padding(4.dp),
                            color = when (cell) {
                                "Present" -> PresentGreen
                                "Absent" -> AbsentRed
                                else -> Color.Unspecified
                            },
                            style = MaterialTheme.typography.bodyMedium
                        )
                    }
                }
            }
        }
    }
    if (report.rows.size > 100) {
        Text(
            "Showing the first 100 of ${report.rows.size} rows. Exported files contain every row.",
            style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}

@Composable
private fun StudentPickerDialog(students: List<Student>, onPick: (Student) -> Unit, onDismiss: () -> Unit) {
    var q by remember { mutableStateOf("") }
    val list = remember(students, q) {
        val t = q.trim()
        (if (t.isEmpty()) students else students.filter { it.name.contains(t, true) || it.rollNumber.contains(t, true) }).take(60)
    }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Choose student") },
        text = {
            Column {
                OutlinedTextField(q, { q = it }, label = { Text("Search name or roll") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                Spacer(Modifier.height(8.dp))
                LazyColumn(Modifier.heightIn(max = 320.dp)) {
                    items(list, key = { it.id }) { s ->
                        TextButton(onClick = { onPick(s) }, modifier = Modifier.fillMaxWidth()) {
                            Text("${s.name} (Roll ${s.rollNumber}, ${classLabel(s)})", modifier = Modifier.fillMaxWidth())
                        }
                    }
                }
            }
        },
        confirmButton = {},
        dismissButton = { TextButton(onClick = onDismiss) { Text("Close") } }
    )
}

@Composable
fun ReportsScreen(students: List<Student>, records: List<AttendanceRecord>) {
    val exporter = rememberExporter()
    var periodName by rememberSaveable { mutableStateOf(ReportPeriod.DAILY.name) }
    val period = ReportPeriod.valueOf(periodName)
    var dateStr by rememberSaveable { mutableStateOf(LocalDate.now().toString()) }
    val date = LocalDate.parse(dateStr)
    var mode by rememberSaveable { mutableIntStateOf(0) } // 0 all, 1 class, 2 student
    var selCls by rememberSaveable { mutableStateOf("") }
    var selSec by rememberSaveable { mutableStateOf("") }
    var studentId by rememberSaveable { mutableLongStateOf(-1L) }
    var picking by remember { mutableStateOf(false) }

    val classKeys = remember(students) {
        students.map { it.className to it.section }.distinct()
            .sortedWith(compareBy<Pair<String, String>>({ it.first.toIntOrNull() ?: Int.MAX_VALUE }, { it.first }, { it.second }))
    }
    val pair = classKeys.firstOrNull { it.first == selCls && it.second == selSec } ?: classKeys.firstOrNull()
    val pickedStudent = students.firstOrNull { it.id == studentId }

    val scope: ReportScope? = when (mode) {
        0 -> ReportScope.All
        1 -> pair?.let { ReportScope.ClassSection(it.first, it.second) }
        else -> pickedStudent?.let { ReportScope.Single(it.id) }
    }
    val report = remember(scope, period, date, students, records) {
        scope?.let { ReportBuilder.build(period, date, it, students, records) }
    }

    ScreenColumn {
        LazyColumn(
            Modifier.fillMaxSize(),
            verticalArrangement = Arrangement.spacedBy(12.dp),
            contentPadding = PaddingValues(bottom = 24.dp)
        ) {
            item { ScreenTitle("Reports") }
            item {
                FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    ReportPeriod.entries.forEach { p ->
                        FilterChip(selected = p == period, onClick = { periodName = p.name }, label = { Text(p.label) })
                    }
                }
            }
            if (period != ReportPeriod.ALL) {
                item {
                    DatePickerButton(date = date, onChange = { dateStr = it.toString() }, modifier = Modifier.fillMaxWidth())
                }
            }
            item {
                FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("All students", "Class-wise", "Individual student").forEachIndexed { i, label ->
                        FilterChip(selected = mode == i, onClick = { mode = i }, label = { Text(label) })
                    }
                }
            }
            if (mode == 1) {
                item {
                    if (classKeys.isEmpty()) Text("No classes yet.")
                    else DropdownField(
                        label = "Class and section",
                        selected = pair?.let { "${it.first}-${it.second}" } ?: "",
                        options = classKeys,
                        optionLabel = { "${it.first}-${it.second}" },
                        onSelect = { selCls = it.first; selSec = it.second },
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }
            if (mode == 2) {
                item {
                    OutlinedButton(onClick = { picking = true }, modifier = Modifier.fillMaxWidth().height(56.dp)) {
                        Text(pickedStudent?.let { "${it.name} (Roll ${it.rollNumber})" } ?: "Choose a student")
                    }
                }
            }
            if (report == null) {
                item { EmptyState("Make a selection above to see the report.") }
            } else {
                item {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(onClick = { exporter.csv(report) }, enabled = report.rows.isNotEmpty()) { Text("Export CSV") }
                        Button(onClick = { exporter.pdf(report) }, enabled = report.rows.isNotEmpty()) { Text("Export PDF") }
                    }
                }
                item {
                    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface), modifier = Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Text(report.title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                            Text(report.subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Spacer(Modifier.height(4.dp))
                            report.summary.forEach { Text(it) }
                        }
                    }
                }
                item {
                    if (report.rows.isEmpty()) EmptyState("No attendance records for this selection.")
                    else Column(verticalArrangement = Arrangement.spacedBy(6.dp)) { ReportTable(report) }
                }
            }
        }
    }

    if (picking) {
        StudentPickerDialog(
            students = students,
            onPick = { studentId = it.id; picking = false },
            onDismiss = { picking = false }
        )
    }
}
