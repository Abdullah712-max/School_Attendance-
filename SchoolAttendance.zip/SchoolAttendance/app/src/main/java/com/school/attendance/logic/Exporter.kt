package com.school.attendance.logic

import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.pdf.PdfDocument
import java.io.ByteArrayOutputStream
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter

object Exporter {

    fun csv(r: Report): ByteArray {
        val sb = StringBuilder("\uFEFF") // BOM so Excel reads UTF-8 names correctly
        fun line(values: List<String>) {
            sb.append(values.joinToString(",") { esc(it) }).append("\r\n")
        }
        line(listOf(r.title))
        line(listOf(r.subtitle))
        r.summary.forEach { line(listOf(it)) }
        line(emptyList())
        if (r.headers.isNotEmpty()) line(r.headers)
        r.rows.forEach { line(it) }
        return sb.toString().toByteArray(Charsets.UTF_8)
    }

    private fun esc(raw: String): String {
        var v = raw
        if (v.isNotEmpty() && v[0] in "=+@") v = "'$v" // avoid spreadsheet formula injection
        return if (v.any { it == ',' || it == '"' || it == '\n' || it == '\r' }) {
            "\"" + v.replace("\"", "\"\"") + "\""
        } else v
    }

    private class PdfCtx {
        val doc = PdfDocument()
        private var page: PdfDocument.Page? = null
        lateinit var canvas: Canvas
        var y = 0f
        private var no = 0

        fun newPage() {
            page?.let { doc.finishPage(it) }
            no++
            val p = doc.startPage(PdfDocument.PageInfo.Builder(PAGE_W, PAGE_H, no).create())
            page = p
            canvas = p.canvas
            y = MARGIN
        }

        fun close(): ByteArray {
            page?.let { doc.finishPage(it) }
            val out = ByteArrayOutputStream()
            doc.writeTo(out)
            doc.close()
            return out.toByteArray()
        }
    }

    private const val PAGE_W = 595
    private const val PAGE_H = 842
    private const val MARGIN = 36f
    private const val BLUE = 0xFF1565C0.toInt()
    private const val GREEN = 0xFF2E7D32.toInt()
    private const val RED = 0xFFC62828.toInt()

    fun pdf(r: Report): ByteArray {
        val c = PdfCtx()
        c.newPage()
        val left = MARGIN
        val width = PAGE_W - 2 * MARGIN

        val titleP = Paint(Paint.ANTI_ALIAS_FLAG).apply { textSize = 18f; isFakeBoldText = true; color = BLUE }
        val subP = Paint(Paint.ANTI_ALIAS_FLAG).apply { textSize = 11f; color = 0xFF444444.toInt() }
        val bodyP = Paint(Paint.ANTI_ALIAS_FLAG).apply { textSize = 10f; color = Color.BLACK }
        val headP = Paint(Paint.ANTI_ALIAS_FLAG).apply { textSize = 10f; isFakeBoldText = true; color = Color.WHITE }
        val fill = Paint().apply { style = Paint.Style.FILL }

        c.canvas.drawText(fit(r.title, titleP, width), left, c.y + 16f, titleP)
        c.y += 28f
        wrap(r.subtitle, subP, width).forEach {
            c.canvas.drawText(it, left, c.y + 11f, subP)
            c.y += 15f
        }
        c.y += 6f
        r.summary.forEach {
            c.canvas.drawText(it, left, c.y + 10f, bodyP)
            c.y += 15f
        }
        val stamp = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm"))
        c.canvas.drawText("Generated: $stamp", left, c.y + 10f, subP)
        c.y += 24f

        if (r.rows.isEmpty()) {
            c.canvas.drawText("No attendance records for this selection.", left, c.y + 10f, bodyP)
            return c.close()
        }

        val weights = r.headers.map {
            when (it) {
                "Name" -> 3f
                "Date" -> 2f
                "Status", "Attendance %" -> 1.6f
                else -> 1.2f
            }
        }
        val total = weights.sum()
        val widths = weights.map { it / total * width }

        fun drawHeader() {
            fill.color = BLUE
            c.canvas.drawRect(left, c.y, left + width, c.y + 20f, fill)
            var x = left
            r.headers.forEachIndexed { i, h ->
                c.canvas.drawText(fit(h, headP, widths[i] - 8f), x + 4f, c.y + 14f, headP)
                x += widths[i]
            }
            c.y += 20f
        }

        drawHeader()
        r.rows.forEachIndexed { idx, row ->
            if (c.y + 18f > PAGE_H - MARGIN) {
                c.newPage()
                drawHeader()
            }
            if (idx % 2 == 1) {
                fill.color = 0xFFF1F4F9.toInt()
                c.canvas.drawRect(left, c.y, left + width, c.y + 18f, fill)
            }
            var x = left
            row.forEachIndexed { i, cell ->
                bodyP.color = when (cell) {
                    "Present" -> GREEN
                    "Absent" -> RED
                    else -> Color.BLACK
                }
                c.canvas.drawText(fit(cell, bodyP, widths[i] - 8f), x + 4f, c.y + 13f, bodyP)
                x += widths[i]
            }
            bodyP.color = Color.BLACK
            c.y += 18f
        }
        return c.close()
    }

    private fun fit(text: String, p: Paint, maxW: Float): String {
        if (p.measureText(text) <= maxW) return text
        var t = text
        while (t.isNotEmpty() && p.measureText("$t...") > maxW) t = t.dropLast(1)
        return "$t..."
    }

    private fun wrap(text: String, p: Paint, maxW: Float): List<String> {
        val lines = mutableListOf<String>()
        var cur = ""
        for (word in text.split(" ")) {
            val t = if (cur.isEmpty()) word else "$cur $word"
            if (cur.isEmpty() || p.measureText(t) <= maxW) cur = t else {
                lines.add(cur)
                cur = word
            }
        }
        if (cur.isNotEmpty()) lines.add(cur)
        return lines
    }
}
