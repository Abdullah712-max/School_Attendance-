package com.school.attendance.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.school.attendance.data.AttendanceRecord
import com.school.attendance.data.Student
import com.school.attendance.logic.Stats
import com.school.attendance.logic.classLabel
import com.school.attendance.logic.pct
import com.school.attendance.logic.pretty
import java.time.LocalDate

@Composable
fun DashboardScreen(students: List<Student>, records: List<AttendanceRecord>) {
    val today = LocalDate.now()
    val todayStr = today.toString()
    val stats = remember(students, records) { Stats.compute(students, records) }
    val todays = remember(records) { records.filter { it.date == todayStr } }
    val presentToday = todays.count { it.present }
    val absentToday = todays.count { !it.present }
    val overall = if (records.isEmpty()) 0f else records.count { it.present } * 100f / records.size
    val topAbsent = remember(stats) { stats.filter { it.absent > 0 }.sortedByDescending { it.absent }.take(5) }
    val frequent = remember(stats) { stats.filter { it.frequentAbsences } }

    ScreenColumn {
        LazyColumn(
            Modifier.fillMaxSize(),
            verticalArrangement = Arrangement.spacedBy(12.dp),
            contentPadding = PaddingValues(bottom = 24.dp)
        ) {
            item {
                ScreenTitle("Dashboard")
                Text(today.pretty(), color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            item {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    StatCard("Total students", students.size.toString(), MaterialTheme.colorScheme.primary, Modifier.weight(1f))
                    StatCard("Overall attendance", pct(overall), MaterialTheme.colorScheme.primary, Modifier.weight(1f))
                }
            }
            item {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    StatCard("Present today", presentToday.toString(), PresentGreen, Modifier.weight(1f))
                    StatCard("Absent today", absentToday.toString(), AbsentRed, Modifier.weight(1f))
                }
            }
            if (students.isNotEmpty() && todays.isEmpty()) {
                item {
                    Text(
                        "Attendance has not been marked today. Open the Attendance tab to mark it.",
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
            item { Text("Students with the most absences", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold) }
            if (topAbsent.isEmpty()) {
                item { Text("No absences recorded yet.", color = MaterialTheme.colorScheme.onSurfaceVariant) }
            } else {
                items(topAbsent, key = { "top" + it.student.id }) { s ->
                    Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                        Row(Modifier.padding(16.dp), verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text(s.student.name, fontWeight = FontWeight.SemiBold)
                                Text(
                                    "Class ${classLabel(s.student)} | Roll ${s.student.rollNumber} | ${pct(s.percent)} attendance",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            Text("${s.absent} absent", color = AbsentRed, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
            if (frequent.isNotEmpty()) {
                item {
                    Text("Frequent absences (below 75% or 3+ days in a row)", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold, color = AbsentRed)
                }
                items(frequent, key = { "freq" + it.student.id }) { s ->
                    Card(
                        Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = AbsentRed.copy(alpha = 0.10f))
                    ) {
                        Column(Modifier.padding(16.dp)) {
                            Text(s.student.name, fontWeight = FontWeight.SemiBold)
                            Text(
                                "Class ${classLabel(s.student)} | ${pct(s.percent)} attendance | ${s.currentStreak} absent in a row now",
                                style = MaterialTheme.typography.bodySmall
                            )
                        }
                    }
                }
            }
        }
    }
}
