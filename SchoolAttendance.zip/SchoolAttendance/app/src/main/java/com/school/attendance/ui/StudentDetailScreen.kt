package com.school.attendance.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.school.attendance.AppViewModel
import com.school.attendance.data.AttendanceRecord
import com.school.attendance.data.Student
import com.school.attendance.logic.*
import java.time.LocalDate

@Composable
fun StudentDetailScreen(
    vm: AppViewModel,
    studentId: Long,
    students: List<Student>,
    records: List<AttendanceRecord>,
    onBack: () -> Unit
) {
    val stat = remember(students, records, studentId) {
        Stats.compute(students.filter { it.id == studentId }, records).firstOrNull()
    }
    val history = remember(records, studentId) {
        records.filter { it.studentId == studentId }.sortedByDescending { it.date }
    }
    val exporter = rememberExporter()

    if (stat == null) {
        LaunchedEffect(Unit) { onBack() }
        return
    }
    val s = stat.student

    ScreenColumn {
        LazyColumn(
            Modifier.fillMaxSize(),
            verticalArrangement = Arrangement.spacedBy(12.dp),
            contentPadding = PaddingValues(bottom = 24.dp)
        ) {
            item {
                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(vertical = 8.dp)) {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                    Column {
                        Text(s.name, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                        Text(
                            "Roll ${s.rollNumber} | Class ${classLabel(s)}" +
                                if (s.parentContact.isNotBlank()) " | Parent: ${s.parentContact}" else "",
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            style = MaterialTheme.typography.bodySmall
                        )
                    }
                }
            }
            if (stat.frequentAbsences) {
                item {
                    Card(colors = CardDefaults.cardColors(containerColor = AbsentRed.copy(alpha = 0.12f)), modifier = Modifier.fillMaxWidth()) {
                        Text(
                            "Frequent absences: attendance is ${pct(stat.percent)} and the student has been absent " +
                                "${stat.currentStreak} school day(s) in a row.",
                            color = AbsentRed, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(16.dp)
                        )
                    }
                }
            }
            item {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    StatCard("Days present", stat.present.toString(), PresentGreen, Modifier.weight(1f))
                    StatCard("Days absent", stat.absent.toString(), AbsentRed, Modifier.weight(1f))
                }
            }
            item {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    StatCard("Attendance", pct(stat.percent), MaterialTheme.colorScheme.primary, Modifier.weight(1f))
                    StatCard(
                        "Absent in a row", stat.currentStreak.toString(),
                        if (stat.currentStreak > 0) AbsentRed else PresentGreen, Modifier.weight(1f)
                    )
                }
            }
            item {
                Text("Longest absent streak: ${stat.longestStreak} day(s)", color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            item {
                val report = ReportBuilder.build(ReportPeriod.ALL, LocalDate.now(), ReportScope.Single(s.id), students, records)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = { exporter.csv(report) }) { Text("Export CSV") }
                    OutlinedButton(onClick = { exporter.pdf(report) }) { Text("Export PDF") }
                }
            }
            item {
                Text("Attendance history (${history.size})", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
            }
            if (history.isEmpty()) {
                item { Text("No attendance recorded yet.", color = MaterialTheme.colorScheme.onSurfaceVariant) }
            } else {
                items(history, key = { it.date }) { r ->
                    Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                        Row(Modifier.padding(horizontal = 16.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                            Text(LocalDate.parse(r.date).pretty(), modifier = Modifier.weight(1f))
                            StatusChip(r.present)
                            TextButton(onClick = { vm.setRecord(s.id, r.date, !r.present) }) {
                                Text(if (r.present) "Mark absent" else "Mark present")
                            }
                        }
                    }
                }
            }
        }
    }
}
