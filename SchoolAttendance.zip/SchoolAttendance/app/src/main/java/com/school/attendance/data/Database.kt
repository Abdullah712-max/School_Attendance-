package com.school.attendance.data

import android.content.Context
import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Entity(
    tableName = "students",
    indices = [Index(value = ["className", "section", "rollNumber"], unique = true)]
)
data class Student(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val rollNumber: String,
    val className: String,
    val section: String,
    val parentContact: String
)

/** One row per student per day. The unique index makes duplicates impossible. */
@Entity(
    tableName = "attendance",
    foreignKeys = [ForeignKey(
        entity = Student::class,
        parentColumns = ["id"],
        childColumns = ["studentId"],
        onDelete = ForeignKey.CASCADE
    )],
    indices = [Index(value = ["studentId", "date"], unique = true)]
)
data class AttendanceRecord(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val studentId: Long,
    val date: String, // ISO yyyy-MM-dd
    val present: Boolean
)

@Dao
interface StudentDao {
    @Query("SELECT * FROM students ORDER BY className, section, CAST(rollNumber AS INTEGER), rollNumber")
    fun observeAll(): Flow<List<Student>>

    @Query("SELECT * FROM students")
    suspend fun getAll(): List<Student>

    @Insert
    suspend fun insert(student: Student): Long

    @Update
    suspend fun update(student: Student)

    @Delete
    suspend fun delete(student: Student)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAllReplace(students: List<Student>)

    @Query("DELETE FROM students")
    suspend fun deleteAll()
}

@Dao
interface AttendanceDao {
    @Query("SELECT * FROM attendance")
    fun observeAll(): Flow<List<AttendanceRecord>>

    @Query("SELECT * FROM attendance")
    suspend fun getAll(): List<AttendanceRecord>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAll(records: List<AttendanceRecord>)

    @Query("DELETE FROM attendance")
    suspend fun deleteAll()
}

@Database(entities = [Student::class, AttendanceRecord::class], version = 1, exportSchema = false)
abstract class AppDatabase : RoomDatabase() {
    abstract fun students(): StudentDao
    abstract fun attendance(): AttendanceDao

    companion object {
        @Volatile
        private var instance: AppDatabase? = null

        fun get(context: Context): AppDatabase =
            instance ?: synchronized(this) {
                instance ?: Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "attendance.db"
                ).build().also { instance = it }
            }
    }
}
