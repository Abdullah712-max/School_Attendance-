package com.school.attendance

import android.app.Application
import android.database.sqlite.SQLiteConstraintException
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.room.withTransaction
import com.school.attendance.data.AppDatabase
import com.school.attendance.data.AttendanceRecord
import com.school.attendance.data.Student
import com.school.attendance.security.AuthManager
import com.school.attendance.security.LoginResult
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.time.LocalDateTime

class AppViewModel(app: Application) : AndroidViewModel(app) {
    private val db = AppDatabase.get(app)
    val auth = AuthManager(app)

    /** null = still loading from the database. */
    val students: StateFlow<List<Student>?> =
        db.students().observeAll().stateIn<List<Student>?>(viewModelScope, SharingStarted.Eagerly, null)
    val records: StateFlow<List<AttendanceRecord>?> =
        db.attendance().observeAll().stateIn<List<AttendanceRecord>?>(viewModelScope, SharingStarted.Eagerly, null)

    var isSetUp by mutableStateOf(auth.isSetUp())
        private set
    var loggedIn by mutableStateOf(false)
        private set

    // ---------- auth ----------
    fun setUpAdmin(username: String, password: String) {
        viewModelScope.launch {
            withContext(Dispatchers.Default) { auth.setUp(username, password) }
            isSetUp = true
            loggedIn = true
        }
    }

    fun login(username: String, password: String, onResult: (LoginResult, Int) -> Unit) {
        viewModelScope.launch {
            val r = withContext(Dispatchers.Default) { auth.login(username, password) }
            if (r == LoginResult.OK) loggedIn = true
            onResult(r, auth.lockSecondsRemaining())
        }
    }

    fun changePassword(old: String, new: String, onResult: (Boolean) -> Unit) {
        viewModelScope.launch {
            val ok = withContext(Dispatchers.Default) { auth.changePassword(old, new) }
            onResult(ok)
        }
    }

    fun logout() {
        loggedIn = false
    }

    // ---------- students ----------
    /** onResult receives an error message, or null on success. */
    fun saveStudent(student: Student, onResult: (String?) -> Unit) {
        viewModelScope.launch {
            val err = try {
                if (student.id == 0L) db.students().insert(student) else db.students().update(student)
                null
            } catch (e: SQLiteConstraintException) {
                "A student with this roll number already exists in that class and section."
            } catch (e: Exception) {
                "Could not save: ${e.message}"
            }
            onResult(err)
        }
    }

    fun deleteStudent(student: Student) {
        viewModelScope.launch { db.students().delete(student) }
    }

    // ---------- attendance ----------
    fun saveAttendance(list: List<AttendanceRecord>, onDone: () -> Unit) {
        viewModelScope.launch {
            db.attendance().upsertAll(list) // unique (studentId,date) + REPLACE => no duplicates, corrections allowed
            onDone()
        }
    }

    fun setRecord(studentId: Long, date: String, present: Boolean) {
        viewModelScope.launch {
            db.attendance().upsertAll(listOf(AttendanceRecord(studentId = studentId, date = date, present = present)))
        }
    }

    // ---------- backup / restore ----------
    suspend fun buildBackup(): String = withContext(Dispatchers.IO) {
        val root = JSONObject()
        root.put("app", "SchoolAttendance")
        root.put("version", 1)
        root.put("exportedAt", LocalDateTime.now().toString())
        val sa = JSONArray()
        db.students().getAll().forEach {
            sa.put(
                JSONObject()
                    .put("id", it.id).put("name", it.name).put("roll", it.rollNumber)
                    .put("className", it.className).put("section", it.section)
                    .put("parentContact", it.parentContact)
            )
        }
        val ra = JSONArray()
        db.attendance().getAll().forEach {
            ra.put(
                JSONObject().put("studentId", it.studentId).put("date", it.date).put("present", it.present)
            )
        }
        root.put("students", sa)
        root.put("attendance", ra)
        root.toString(1)
    }

    private class Parsed(val students: List<Student>, val records: List<AttendanceRecord>)

    private fun parse(json: String): Parsed {
        val root = JSONObject(json)
        require(root.optString("app") == "SchoolAttendance") { "This is not a School Attendance backup file." }
        val sa = root.getJSONArray("students")
        val students = (0 until sa.length()).map { i ->
            val o = sa.getJSONObject(i)
            Student(
                id = o.getLong("id"), name = o.getString("name"), rollNumber = o.getString("roll"),
                className = o.getString("className"), section = o.getString("section"),
                parentContact = o.optString("parentContact", "")
            )
        }
        val ids = students.map { it.id }.toSet()
        val ra = root.getJSONArray("attendance")
        val records = (0 until ra.length()).map { i ->
            val o = ra.getJSONObject(i)
            AttendanceRecord(studentId = o.getLong("studentId"), date = o.getString("date"), present = o.getBoolean("present"))
        }.filter { it.studentId in ids }
            .associateBy { it.studentId to it.date } // de-duplicate
            .values.toList()
        return Parsed(students, records)
    }

    /** Replaces ALL current data with the backup. onResult gets an error message or null on success. */
    fun restoreBackup(json: String, onResult: (String?) -> Unit) {
        viewModelScope.launch {
            val msg = try {
                val parsed = withContext(Dispatchers.Default) { parse(json) }
                db.withTransaction {
                    db.attendance().deleteAll()
                    db.students().deleteAll()
                    db.students().insertAllReplace(parsed.students)
                    db.attendance().upsertAll(parsed.records)
                }
                null
            } catch (e: Exception) {
                "Restore failed: ${e.message}"
            }
            onResult(msg)
        }
    }
}
