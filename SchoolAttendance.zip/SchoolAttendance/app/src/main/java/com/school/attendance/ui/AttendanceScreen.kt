package com.school.attendance.ui

import android.widget.Toast
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.school.attendance.AppViewModel
import com.school.attendance.data.AttendanceRecord
import com.school.attendance.data.Student
import com.school.attendance.logic.classOrder
import com.school.attendance.logic.pretty
import java.time.LocalDate

@Composable
private fun MarkButton(text: String, selected: Boolean, color: Color, onClick: () -> Unit) {
    val padding = PaddingValues(horizontal = 10.dp)
    if (selected) {
        Button(
            onClick = onClick,
            colors = ButtonDefaults.buttonColors(containerColor = color, contentColor = Color.White),
            contentPadding = padding
        ) { Text(text) }
    } else {
        OutlinedButton(
            onClick = onClick,
            colors = ButtonDefaults.outlinedButtonColors(contentColor = color),
            border = BorderStroke(1.dp, color.copy(alpha = 0.5f)),
            contentPadding = padding
        ) { Text(text) }
    }
}

@Composable
fun AttendanceScreen(vm: AppViewModel, students: List<Student>, records: List<AttendanceRecord>) {
    val context = LocalContext.current
    var clsSel by rememberSaveable { mutableStateOf("") }
    var secSel by rememberSaveable { mutableStateOf("") }
    var dateStr by rememberSaveable { mutableStateOf(LocalDate.now().toString()) }
    val date = LocalDate.parse(dateStr)

    val classes = remember(students) { students.map { it.className }.distinct().sortedWith(classOrder) }
    val cls = if (clsSel in classes) clsSel else classes.firstOrNull().orEmpty()
    val sections = remember(students, cls) { students.filter { it.className == cls }.map { it.section }.distinct().sorted() }
    val sec = if (secSel in sections) secSel else sections.firstOrNull().orEmpty()
    val classStudents = remember(students, cls, sec) { students.filter { it.className == cls && it.section == sec } }
    val existing = remember(records, dateStr) { records.filter { it.date == dateStr }.associate { it.studentId to it.present } }
    val marks = remember(cls, sec, dateStr, classStudents) {
        mutableStateMapOf<Long, Boolean>().apply {
            classStudents.forEach { put(it.id, existing[it.id] ?: true) }
        }
    }
    val alreadySaved = classStudents.any { existing.containsKey(it.id) }

    ScreenColumn {
        ScreenTitle("Mark attendance")
        if (classes.isEmpty()) {
            EmptyState("Add students first (Students tab), then mark their attendance here.")
            return@ScreenColumn
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            DropdownField("Class", cls, classes, { it }, { clsSel = it; secSel = "" }, Modifier.weight(1f))
            DropdownField("Section", sec, sections, { it }, { secSel = it }, Modifier.weight(1f))
        }
        Spacer(Modifier.height(8.dp))
        DatePickerButton(date = date, onChange = { dateStr = it.toString() }, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(8.dp))

        if (alreadySaved) {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    "Attendance for this class and date was already saved. Saving again will correct it (no duplicates are created).",
                    modifier = Modifier.padding(12.dp),
                    style = MaterialTheme.typography.bodySmall
                )
            }
            Spacer(Modifier.height(8.dp))
        }

        val presentCount = classStudents.count { marks[it.id] != false }
        val absentCount = classStudents.size - presentCount
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Present: $presentCount", color = PresentGreen, fontWeight = FontWeight.Bold)
            Spacer(Modifier.width(16.dp))
            Text("Absent: $absentCount", color = AbsentRed, fontWeight = FontWeight.Bold)
            Spacer(Modifier.weight(1f))
            TextButton(onClick = { classStudents.forEach { marks[it.id] = true } }) { Text("All present") }
            TextButton(onClick = { classStudents.forEach { marks[it.id] = false } }) { Text("All absent") }
        }

        LazyColumn(
            Modifier.weight(1f),
            verticalArrangement = Arrangement.spacedBy(8.dp),
            contentPadding = PaddingValues(vertical = 4.dp)
        ) {
            items(classStudents, key = { it.id }) { s ->
                val isPresent = marks[s.id] != false
                Card(
                    Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(
                        containerColor = (if (isPresent) PresentGreen else AbsentRed).copy(alpha = 0.08f)
                    )
                ) {
                    Row(Modifier.padding(horizontal = 12.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(s.name, fontWeight = FontWeight.SemiBold)
                            Text("Roll ${s.rollNumber}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        MarkButton("Present", isPresent, PresentGreen) { marks[s.id] = true }
                        Spacer(Modifier.width(6.dp))
                        MarkButton("Absent", !isPresent, AbsentRed) { marks[s.id] = false }
                    }
                }
            }
        }

        Button(
            onClick = {
                val list = classStudents.map {
                    AttendanceRecord(studentId = it.id, date = dateStr, present = marks[it.id] != false)
                }
                vm.saveAttendance(list) {
                    Toast.makeText(context, "Attendance saved for ${date.pretty()}", Toast.LENGTH_SHORT).show()
                }
            },
            enabled = classStudents.isNotEmpty(),
            modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp).height(52.dp)
        ) { Text(if (alreadySaved) "Update attendance" else "Save attendance") }
    }
}
