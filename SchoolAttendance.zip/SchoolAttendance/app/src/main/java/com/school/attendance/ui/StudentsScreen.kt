package com.school.attendance.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.school.attendance.AppViewModel
import com.school.attendance.data.AttendanceRecord
import com.school.attendance.data.Student
import com.school.attendance.logic.Stats
import com.school.attendance.logic.classLabel

@Composable
fun StudentsScreen(
    vm: AppViewModel,
    students: List<Student>,
    records: List<AttendanceRecord>,
    onOpen: (Long) -> Unit
) {
    var query by rememberSaveable { mutableStateOf("") }
    var editing by remember { mutableStateOf<Student?>(null) }
    var showForm by remember { mutableStateOf(false) }
    var deleting by remember { mutableStateOf<Student?>(null) }
    val statsById = remember(students, records) { Stats.compute(students, records).associateBy { it.student.id } }
    val filtered = remember(students, query) {
        val q = query.trim()
        if (q.isEmpty()) students
        else students.filter { it.name.contains(q, ignoreCase = true) || it.rollNumber.contains(q, ignoreCase = true) }
    }

    Box(Modifier.fillMaxSize()) {
        ScreenColumn {
            ScreenTitle("Students")
            OutlinedTextField(
                value = query,
                onValueChange = { query = it },
                label = { Text("Search by name or roll number") },
                leadingIcon = { Icon(Icons.Filled.Search, contentDescription = null) },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(Modifier.height(8.dp))
            if (filtered.isEmpty()) {
                EmptyState(
                    if (students.isEmpty()) "No students yet. Tap + to add your first student."
                    else "No students match your search."
                )
            } else {
                LazyColumn(
                    Modifier.fillMaxSize(),
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                    contentPadding = PaddingValues(bottom = 96.dp)
                ) {
                    items(filtered, key = { it.id }) { s ->
                        Card(
                            onClick = { onOpen(s.id) },
                            modifier = Modifier.fillMaxWidth(),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                        ) {
                            Row(Modifier.padding(start = 16.dp, top = 8.dp, bottom = 8.dp, end = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                                Column(Modifier.weight(1f)) {
                                    Text(s.name, fontWeight = FontWeight.SemiBold, style = MaterialTheme.typography.titleMedium)
                                    Text(
                                        "Roll ${s.rollNumber} | Class ${classLabel(s)}" +
                                            if (s.parentContact.isNotBlank()) " | ${s.parentContact}" else "",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                    if (statsById[s.id]?.frequentAbsences == true) {
                                        Spacer(Modifier.height(4.dp))
                                        FrequentBadge()
                                    }
                                }
                                IconButton(onClick = { editing = s; showForm = true }) {
                                    Icon(Icons.Filled.Edit, contentDescription = "Edit ${s.name}")
                                }
                                IconButton(onClick = { deleting = s }) {
                                    Icon(Icons.Filled.Delete, contentDescription = "Delete ${s.name}", tint = AbsentRed)
                                }
                            }
                        }
                    }
                }
            }
        }
        FloatingActionButton(
            onClick = { editing = null; showForm = true },
            modifier = Modifier.align(Alignment.BottomEnd).padding(16.dp)
        ) { Icon(Icons.Filled.Add, contentDescription = "Add student") }
    }

    if (showForm) {
        StudentFormDialog(initial = editing, vm = vm, onDismiss = { showForm = false })
    }
    deleting?.let { s ->
        AlertDialog(
            onDismissRequest = { deleting = null },
            title = { Text("Delete student?") },
            text = { Text("${s.name} and ALL of their attendance records will be permanently deleted. This cannot be undone.") },
            confirmButton = {
                TextButton(onClick = { vm.deleteStudent(s); deleting = null }) { Text("Delete", color = AbsentRed) }
            },
            dismissButton = { TextButton(onClick = { deleting = null }) { Text("Cancel") } }
        )
    }
}

@Composable
fun StudentFormDialog(initial: Student?, vm: AppViewModel, onDismiss: () -> Unit) {
    var name by remember { mutableStateOf(initial?.name ?: "") }
    var roll by remember { mutableStateOf(initial?.rollNumber ?: "") }
    var cls by remember { mutableStateOf(initial?.className ?: "") }
    var sec by remember { mutableStateOf(initial?.section ?: "") }
    var contact by remember { mutableStateOf(initial?.parentContact ?: "") }
    var error by remember { mutableStateOf<String?>(null) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (initial == null) "Add student" else "Edit student") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(name, { name = it }, label = { Text("Student name") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(roll, { roll = it }, label = { Text("Roll number") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(cls, { cls = it }, label = { Text("Class") }, singleLine = true, modifier = Modifier.weight(1f))
                    OutlinedTextField(sec, { sec = it }, label = { Text("Section") }, singleLine = true, modifier = Modifier.weight(1f))
                }
                OutlinedTextField(
                    contact, { contact = it }, label = { Text("Parent contact number") }, singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                    modifier = Modifier.fillMaxWidth()
                )
                error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                val phoneOk = contact.isBlank() || Regex("^[+0-9 ()-]{7,20}$").matches(contact.trim())
                when {
                    name.isBlank() || roll.isBlank() || cls.isBlank() || sec.isBlank() ->
                        error = "Name, roll number, class and section are required."
                    !phoneOk -> error = "Enter a valid phone number (digits, +, spaces)."
                    else -> vm.saveStudent(
                        Student(
                            id = initial?.id ?: 0L,
                            name = name.trim(),
                            rollNumber = roll.trim(),
                            className = cls.trim(),
                            section = sec.trim().uppercase(),
                            parentContact = contact.trim()
                        )
                    ) { err -> if (err == null) onDismiss() else error = err }
                }
            }) { Text("Save") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}
