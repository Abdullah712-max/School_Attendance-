package com.school.attendance.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.DateRange
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalConfiguration
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.school.attendance.AppViewModel

private data class NavItem(val label: String, val icon: ImageVector)

private val navItems = listOf(
    NavItem("Home", Icons.Filled.Home),
    NavItem("Students", Icons.Filled.Person),
    NavItem("Attendance", Icons.Filled.CheckCircle),
    NavItem("Reports", Icons.Filled.DateRange),
    NavItem("Settings", Icons.Filled.Settings)
)

@Composable
fun AppRoot(vm: AppViewModel) {
    when {
        !vm.isSetUp -> SetupScreen(vm)
        !vm.loggedIn -> LoginScreen(vm)
        else -> MainApp(vm)
    }
}

@Composable
private fun MainApp(vm: AppViewModel) {
    val studentsState by vm.students.collectAsStateWithLifecycle()
    val recordsState by vm.records.collectAsStateWithLifecycle()
    var tab by rememberSaveable { mutableIntStateOf(0) }
    var detailId by rememberSaveable { mutableStateOf<Long?>(null) }
    val wide = LocalConfiguration.current.screenWidthDp >= 600

    BackHandler(enabled = detailId != null) { detailId = null }
    BackHandler(enabled = detailId == null && tab != 0) { tab = 0 }

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        bottomBar = {
            if (!wide) {
                NavigationBar {
                    navItems.forEachIndexed { i, item ->
                        NavigationBarItem(
                            selected = tab == i,
                            onClick = { tab = i; detailId = null },
                            icon = { Icon(item.icon, contentDescription = item.label) },
                            label = { Text(item.label) }
                        )
                    }
                }
            }
        }
    ) { inner ->
        Row(Modifier.fillMaxSize().padding(inner)) {
            if (wide) {
                NavigationRail {
                    Spacer(Modifier.weight(1f))
                    navItems.forEachIndexed { i, item ->
                        NavigationRailItem(
                            selected = tab == i,
                            onClick = { tab = i; detailId = null },
                            icon = { Icon(item.icon, contentDescription = item.label) },
                            label = { Text(item.label) }
                        )
                    }
                    Spacer(Modifier.weight(1f))
                }
            }
            Box(Modifier.weight(1f).fillMaxHeight()) {
                val students = studentsState
                val records = recordsState
                if (students == null || records == null) {
                    CircularProgressIndicator(Modifier.align(Alignment.Center))
                } else when (tab) {
                    0 -> DashboardScreen(students, records)
                    1 -> {
                        val id = detailId
                        if (id == null) StudentsScreen(vm, students, records) { detailId = it }
                        else StudentDetailScreen(vm, id, students, records) { detailId = null }
                    }
                    2 -> AttendanceScreen(vm, students, records)
                    3 -> ReportsScreen(students, records)
                    else -> SettingsScreen(vm)
                }
            }
        }
    }
}
