package com.school.attendance.logic

import com.school.attendance.data.AttendanceRecord
import com.school.attendance.data.Student
import java.time.DayOfWeek
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.time.format.TextStyle
import java.time.temporal.TemporalAdjusters
import java.util.Locale

fun LocalDate.pretty(): String =
    format(DateTimeFormatter.ofPattern("EEE, d MMM yyyy", Locale.getDefault()))

fun pct(value: Float): String = String.format(Locale.US, "%.1f%%", value)

fun classLabel(s: Student): String = "${s.className}-${s.section}"

/** Sorts "2" before "10", then alphabetically. */
val classOrder: Comparator<String> = compareBy<String>({ it.toIntOrNull() ?: Int.MAX_VALUE }, { it })

data class StudentStats(
    val student: Student,
    val present: Int,
    val absent: Int,
    /** Consecutive absent school days counted back from the latest recorded day. */
    val currentStreak: Int,
    val longestStreak: Int
) {
    val total: Int get() = present + absent
    val percent: Float get() = if (total == 0) 0f else present * 100f / total

    /** Frequent absentee: below 75% attendance (with at least 5 recorded days) or 3+ absences in a row. */
    val frequentAbsences: Boolean get() = (total >= 5 && percent < 75f) || currentStreak >= 3
}

object Stats {
    fun compute(students: List<Student>, records: List<AttendanceRecord>): List<StudentStats> {
        val byStudent = records.groupBy { it.studentId }
        return students.map { s ->
            val recs = (byStudent[s.id] ?: emptyList()).sortedBy { it.date }
            var run = 0
            var longest = 0
            for (r in recs) {
                if (!r.present) {
                    run++
                    if (run > longest) longest = run
                } else run = 0
            }
            StudentStats(s, recs.count { it.present }, recs.count { !it.present }, run, longest)
        }
    }
}

enum class ReportPeriod(val label: String) {
    DAILY("Daily"), WEEKLY("Weekly"), MONTHLY("Monthly"), ALL("Full history")
}

sealed interface ReportScope {
    data object All : ReportScope
    data class ClassSection(val cls: String, val sec: String) : ReportScope
    data class Single(val studentId: Long) : ReportScope
}

data class Report(
    val title: String,
    val subtitle: String,
    val summary: List<String>,
    val headers: List<String>,
    val rows: List<List<String>>
) {
    val fileName: String
        get() = (title + "_" + subtitle).replace(Regex("[^A-Za-z0-9]+"), "_").trim('_').take(60)
}

object ReportBuilder {
    private fun range(period: ReportPeriod, anchor: LocalDate): Pair<String, String> = when (period) {
        ReportPeriod.DAILY -> anchor.toString() to anchor.toString()
        ReportPeriod.WEEKLY -> {
            val start = anchor.with(TemporalAdjusters.previousOrSame(DayOfWeek.MONDAY))
            start.toString() to start.plusDays(6).toString()
        }
        ReportPeriod.MONTHLY -> {
            val start = anchor.withDayOfMonth(1)
            start.toString() to start.withDayOfMonth(start.lengthOfMonth()).toString()
        }
        ReportPeriod.ALL -> "0000-01-01" to "9999-12-31"
    }

    fun build(
        period: ReportPeriod,
        anchor: LocalDate,
        scope: ReportScope,
        students: List<Student>,
        records: List<AttendanceRecord>
    ): Report {
        val (from, to) = range(period, anchor)
        val inRange = records.filter { it.date >= from && it.date <= to }
        val rangeLabel = when (period) {
            ReportPeriod.DAILY -> anchor.pretty()
            ReportPeriod.WEEKLY -> "$from to $to"
            ReportPeriod.MONTHLY -> anchor.format(DateTimeFormatter.ofPattern("MMMM yyyy", Locale.getDefault()))
            ReportPeriod.ALL -> "All dates"
        }
        val subtitleBase = "${period.label} | $rangeLabel"

        if (scope is ReportScope.Single) {
            val s = students.firstOrNull { it.id == scope.studentId }
                ?: return Report("Student Attendance Report", subtitleBase, listOf("Student not found."), emptyList(), emptyList())
            val recs = inRange.filter { it.studentId == s.id }.sortedBy { it.date }
            val st = Stats.compute(listOf(s), inRange).first()
            val rows = recs.map {
                listOf(
                    it.date,
                    LocalDate.parse(it.date).dayOfWeek.getDisplayName(TextStyle.SHORT, Locale.getDefault()),
                    if (it.present) "Present" else "Absent"
                )
            }
            return Report(
                title = "Student Attendance Report",
                subtitle = "${s.name} (Roll ${s.rollNumber}, Class ${classLabel(s)}) | $subtitleBase",
                summary = listOf(
                    "Days present: ${st.present}",
                    "Days absent: ${st.absent}",
                    "Attendance: ${pct(st.percent)}",
                    "Consecutive absent days (current): ${st.currentStreak}",
                    "Longest absent streak: ${st.longestStreak}"
                ),
                headers = listOf("Date", "Day", "Status"),
                rows = rows
            )
        }

        val group = when (scope) {
            is ReportScope.ClassSection -> students.filter { it.className == scope.cls && it.section == scope.sec }
            else -> students
        }
        val title = when (scope) {
            is ReportScope.ClassSection -> "Attendance Report - Class ${scope.cls}-${scope.sec}"
            else -> "Attendance Report - All Classes"
        }

        if (period == ReportPeriod.DAILY) {
            val status = inRange.associate { it.studentId to it.present }
            val rows = group.map {
                listOf(
                    it.rollNumber, it.name, classLabel(it),
                    when (status[it.id]) {
                        true -> "Present"
                        false -> "Absent"
                        null -> "Not marked"
                    }
                )
            }
            val p = group.count { status[it.id] == true }
            val a = group.count { status[it.id] == false }
            val marked = p + a
            return Report(
                title, subtitleBase,
                listOf(
                    "Students: ${group.size}",
                    "Present: $p",
                    "Absent: $a",
                    "Not marked: ${group.size - marked}",
                    "Attendance (marked students): ${pct(if (marked == 0) 0f else p * 100f / marked)}"
                ),
                listOf("Roll", "Name", "Class", "Status"), rows
            )
        }

        val stats = Stats.compute(group, inRange)
        val rows = stats.map {
            listOf(
                it.student.rollNumber, it.student.name, classLabel(it.student),
                it.present.toString(), it.absent.toString(), pct(it.percent)
            )
        }
        val totalP = stats.sumOf { it.present }
        val totalAll = stats.sumOf { it.total }
        return Report(
            title, subtitleBase,
            listOf(
                "Students: ${group.size}",
                "School days recorded: ${inRange.map { it.date }.distinct().size}",
                "Overall attendance: ${pct(if (totalAll == 0) 0f else totalP * 100f / totalAll)}"
            ),
            listOf("Roll", "Name", "Class", "Present", "Absent", "Attendance %"), rows
        )
    }
}
