package com.school.attendance.security

import android.content.Context
import android.util.Base64
import java.security.MessageDigest
import java.security.SecureRandom
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.PBEKeySpec

enum class LoginResult { OK, WRONG, LOCKED }

/**
 * Admin credentials. There is NO default password: the admin creates the account on first launch.
 * Only a salted PBKDF2-HMAC-SHA256 hash is stored (never the password itself).
 */
class AuthManager(context: Context) {
    private val prefs =
        context.applicationContext.getSharedPreferences("admin_auth", Context.MODE_PRIVATE)
    private var failedAttempts = 0
    private var lockedUntilMs = 0L

    fun isSetUp(): Boolean = prefs.contains(KEY_HASH)

    fun setUp(username: String, password: String) {
        store(username.trim(), password)
    }

    @Synchronized
    fun lockSecondsRemaining(): Int {
        val left = lockedUntilMs - System.currentTimeMillis()
        return if (left > 0) ((left + 999) / 1000).toInt() else 0
    }

    @Synchronized
    fun login(username: String, password: String): LoginResult {
        if (lockSecondsRemaining() > 0) return LoginResult.LOCKED
        return if (verify(username.trim(), password)) {
            failedAttempts = 0
            LoginResult.OK
        } else {
            failedAttempts++
            if (failedAttempts >= MAX_ATTEMPTS) {
                failedAttempts = 0
                lockedUntilMs = System.currentTimeMillis() + LOCK_MS
                LoginResult.LOCKED
            } else LoginResult.WRONG
        }
    }

    fun changePassword(oldPassword: String, newPassword: String): Boolean {
        val user = prefs.getString(KEY_USER, "") ?: ""
        if (!verify(user, oldPassword)) return false
        store(user, newPassword)
        return true
    }

    private fun verify(username: String, password: String): Boolean {
        val savedUser = prefs.getString(KEY_USER, null) ?: return false
        val salt = prefs.getString(KEY_SALT, null)?.let { Base64.decode(it, Base64.NO_WRAP) } ?: return false
        val savedHash = prefs.getString(KEY_HASH, null)?.let { Base64.decode(it, Base64.NO_WRAP) } ?: return false
        val candidate = hash(password, salt)
        val hashOk = MessageDigest.isEqual(candidate, savedHash)
        return hashOk && savedUser == username
    }

    private fun store(username: String, password: String) {
        val salt = ByteArray(16).also { SecureRandom().nextBytes(it) }
        prefs.edit()
            .putString(KEY_USER, username)
            .putString(KEY_SALT, Base64.encodeToString(salt, Base64.NO_WRAP))
            .putString(KEY_HASH, Base64.encodeToString(hash(password, salt), Base64.NO_WRAP))
            .commit()
    }

    private fun hash(password: String, salt: ByteArray): ByteArray {
        val spec = PBEKeySpec(password.toCharArray(), salt, ITERATIONS, 256)
        try {
            return SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).encoded
        } finally {
            spec.clearPassword()
        }
    }

    companion object {
        private const val KEY_USER = "user"
        private const val KEY_SALT = "salt"
        private const val KEY_HASH = "hash"
        private const val ITERATIONS = 120_000
        private const val MAX_ATTEMPTS = 5
        private const val LOCK_MS = 30_000L
    }
}
