package com.school.attendance.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.unit.dp
import com.school.attendance.AppViewModel
import com.school.attendance.security.LoginResult

@Composable
private fun AuthContainer(title: String, subtitle: String, content: @Composable ColumnScope.() -> Unit) {
    Box(
        Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .systemBarsPadding()
            .imePadding(),
        contentAlignment = Alignment.Center
    ) {
        Card(
            Modifier.widthIn(max = 440.dp).padding(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            elevation = CardDefaults.cardElevation(4.dp)
        ) {
            Column(
                Modifier.padding(24.dp).verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text("School Attendance", style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.primary)
                Text(title, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                Text(subtitle, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                content()
            }
        }
    }
}

@Composable
private fun PasswordField(label: String, value: String, onChange: (String) -> Unit, imeAction: ImeAction = ImeAction.Next) {
    var visible by remember { mutableStateOf(false) }
    OutlinedTextField(
        value = value,
        onValueChange = onChange,
        label = { Text(label) },
        singleLine = true,
        modifier = Modifier.fillMaxWidth(),
        visualTransformation = if (visible) VisualTransformation.None else PasswordVisualTransformation(),
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password, imeAction = imeAction),
        trailingIcon = { TextButton(onClick = { visible = !visible }) { Text(if (visible) "Hide" else "Show") } }
    )
}

@Composable
fun SetupScreen(vm: AppViewModel) {
    var user by remember { mutableStateOf("") }
    var pass by remember { mutableStateOf("") }
    var confirm by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }

    AuthContainer(
        title = "Create admin account",
        subtitle = "First-time setup. Choose your own username and a strong password (at least 8 characters). " +
            "There is no default password and no password recovery, so keep it safe."
    ) {
        OutlinedTextField(
            value = user, onValueChange = { user = it }, label = { Text("Admin username") },
            singleLine = true, modifier = Modifier.fillMaxWidth()
        )
        PasswordField("Password", pass, { pass = it })
        PasswordField("Confirm password", confirm, { confirm = it }, ImeAction.Done)
        error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
        Button(
            modifier = Modifier.fillMaxWidth().height(52.dp),
            onClick = {
                error = when {
                    user.isBlank() -> "Enter a username."
                    pass.length < 8 -> "Password must be at least 8 characters."
                    pass != confirm -> "Passwords do not match."
                    else -> null
                }
                if (error == null) vm.setUpAdmin(user, pass)
            }
        ) { Text("Create account") }
    }
}

@Composable
fun LoginScreen(vm: AppViewModel) {
    var user by remember { mutableStateOf("") }
    var pass by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }
    var busy by remember { mutableStateOf(false) }

    AuthContainer(title = "Admin login", subtitle = "Sign in to manage students and attendance.") {
        OutlinedTextField(
            value = user, onValueChange = { user = it }, label = { Text("Username") },
            singleLine = true, modifier = Modifier.fillMaxWidth()
        )
        PasswordField("Password", pass, { pass = it }, ImeAction.Done)
        error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
        Button(
            enabled = !busy,
            modifier = Modifier.fillMaxWidth().height(52.dp),
            onClick = {
                busy = true
                vm.login(user, pass) { result, lockSeconds ->
                    busy = false
                    error = when (result) {
                        LoginResult.OK -> null
                        LoginResult.WRONG -> "Incorrect username or password."
                        LoginResult.LOCKED -> "Too many attempts. Try again in $lockSeconds seconds."
                    }
                    if (result != LoginResult.OK) pass = ""
                }
            }
        ) { Text(if (busy) "Checking..." else "Sign in") }
    }
}
